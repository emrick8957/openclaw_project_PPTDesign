# 自检报告 v0.1

## Skill 链路
- 已读取 SKILL.md、generation_workflow、topic_router、output_contracts、anti_overfit、audience_rules、reference_ingestion_workflow、reference_material_policy。
- 已加载 default_general、page_types、narrative_patterns、visual_rules、chart_patterns、wording_rules、layout_library 与相关 methodology/eval。

## 内容验收
- 汇报对象明确：技术高层 / 工程研发负责人 / 制造数字化决策人。
- 章节结构完整：开场、核心判断、论文框架、技术抓手、落地启示、决策收口。
- 每页均为结论型标题，未使用“建设背景/总体架构”等名词式标题。
- 未编造企业数据；企业场景、投入产出、责任边界均列为数据缺口。

## deck_spec 字段检查
- chart_type 均来自 templates/chart_patterns.md。
- layout_pattern 均来自 visual_patterns/layout_library.md。
- 未出现 chart_type == layout_pattern。
- 无自造枚举。

## 视觉一致性检查
- 每页包含 red_anchor、card_hierarchy、spacing_rule、bottom_bar_rule、visual_simplification。
- 普通正文页不使用厚重红色底部条。
- 页脚、安全区、卡片层级和红色锚点均已约束。

## 主题污染检查
- 未引入昇腾、英伟达、NVIDIA、CUDA、CANN、GPU/NPU 等无关专属术语。
- 虽主题涉及 AI，但未套用 AI 算力竞品对比结构。

## 参考材料边界
- PDF 作为事实依据和论证参考；未将论文图直接复制为素材。
- 论文中的具体案例只作为当前任务依据，不沉淀为通用长期规则。
